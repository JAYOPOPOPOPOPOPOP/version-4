// Public route: GET /api/m/monthly-sells/data  (only counts, no money amounts or player names)
module.exports = function (api) {
  api.get('/data', function (req, res) {
    var now = new Date(), months = [], map = {};
    for (var i = 5; i >= 0; i--) {
      var d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      var key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
      map[key] = months.length;
      months.push({ key: key, label: d.toLocaleString('en', { month: 'short' }), count: 0 });
    }
    api.db.sales().forEach(function (s) {
      var dt = new Date(s.createdAt);
      var key = dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0');
      if (key in map) months[map[key]].count += (s.qty || 1);
    });
    api.json(res, 200, { success: true, months: months });
  });
};
