NXModules.register('monthly-sells', {
  mount: function (el, ctx) {
    el.innerHTML = '<div class="chart">Loading...</div>';
    ctx.api('/data').then(function (d) {
      var max = Math.max.apply(null, d.months.map(function (m) { return m.count; }).concat([1]));
      el.querySelector('.chart').innerHTML = d.months.map(function (m) {
        return '<div class="col"><span class="val">' + m.count + '</span><div class="bar" style="height:' + Math.max(3, Math.round(m.count / max * 100)) + '%"></div><span class="lbl">' + m.label + '</span></div>';
      }).join('');
    }).catch(function () { el.innerHTML = 'Could not load.'; });
  }
});
