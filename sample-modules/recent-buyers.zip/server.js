// Public route: GET /api/m/recent-buyers/list
// Only the Minecraft name, product and time are exposed (no email, no money amount).
module.exports = function (api) {
  api.get('/list', function (req, res) {
    var list = api.db.sales()
      .filter(function (s) { return s.mcUsername && s.createdAt; })
      .sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)); })
      .slice(0, 5)
      .map(function (s) { return { player: s.mcUsername, product: s.product || '', at: s.createdAt }; });
    res.setHeader('Cache-Control', 'no-cache');
    api.json(res, 200, { success: true, list: list });
  });
};
