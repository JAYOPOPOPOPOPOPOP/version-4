NXModules.register('recent-buyers', {
  mount: function (el, ctx) {
    el.innerHTML = '<div class="list">Loading...</div>';
    var list = el.querySelector('.list');
    function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
    function ago(iso) {
      var s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
      if (s < 60) return 'just now';
      if (s < 3600) return Math.floor(s / 60) + ' min ago';
      if (s < 86400) return Math.floor(s / 3600) + ' hr ago';
      return Math.floor(s / 86400) + ' day' + (s >= 172800 ? 's' : '') + ' ago';
    }
    function load() {
      ctx.api('/list').then(function (d) {
        if (!d.list || !d.list.length) { list.innerHTML = '<div class="empty">No purchases yet. Be the first!</div>'; return; }
        list.innerHTML = d.list.map(function (b) {
          return '<div class="row"><img class="head" src="https://mc-heads.net/avatar/' + encodeURIComponent(b.player) + '/64" alt="" onerror="this.style.visibility=\'hidden\'">' +
            '<div class="info"><div class="player">' + esc(b.player) + '</div><div class="prod">bought ' + esc(b.product) + '</div></div>' +
            '<span class="ago">' + ago(b.at) + '</span></div>';
        }).join('');
      }).catch(function () { list.innerHTML = '<div class="empty">Could not load.</div>'; });
    }
    load();
    setInterval(load, 60000);
  }
});
