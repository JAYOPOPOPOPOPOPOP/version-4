NXModules.register('top-buys', {
  mount: function (el, ctx) {
    var period = 'month';
    el.innerHTML = '<div class="tabs"><button class="tab on" data-p="month">This month</button><button class="tab" data-p="all">All time</button></div><div class="list">Loading...</div>';
    var list = el.querySelector('.list');
    function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
    function load() {
      ctx.api('/list?period=' + period).then(function (d) {
        if (!d.list || !d.list.length) { list.innerHTML = '<div class="empty">No sales yet.</div>'; return; }
        list.innerHTML = d.list.map(function (it, i) {
          return '<div class="row"><span class="rank">' + (i + 1) + '</span>' +
            (it.image ? '<img class="img" src="' + esc(it.image) + '" alt="">' : '') +
            '<span class="name">' + esc(it.name) + '</span><span class="cnt">' + it.count + ' sold</span></div>';
        }).join('');
      }).catch(function () { list.innerHTML = '<div class="empty">Could not load.</div>'; });
    }
    el.querySelectorAll('.tab').forEach(function (b) {
      b.onclick = function () {
        period = b.dataset.p;
        el.querySelectorAll('.tab').forEach(function (x) { x.classList.toggle('on', x === b); });
        load();
      };
    });
    load();
  }
});
