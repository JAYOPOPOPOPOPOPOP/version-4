// Backend of the module. Public route: GET /api/m/top-buys/list?period=month|all
module.exports = function (api) {
  api.get('/list', function (req, res, c) {
    var period = c.query.period === 'all' ? 'all' : 'month';
    var now = new Date();
    var from = period === 'month' ? new Date(now.getFullYear(), now.getMonth(), 1).toISOString() : '';
    var counts = {};
    api.db.sales().forEach(function (s) {
      if (from && String(s.createdAt) < from) return;
      var key = s.productId || s.product || 'unknown';
      if (!counts[key]) counts[key] = { productId: s.productId, name: s.product || 'Unknown', count: 0 };
      counts[key].count += (s.qty || 1);
    });
    var products = {};
    api.db.products().forEach(function (p) { products[p.id] = p; });
    var list = Object.keys(counts).map(function (k) {
      var it = counts[k], p = products[it.productId];
      return { name: p ? p.name : it.name, count: it.count, image: p ? p.image : '', price: p ? p.price : null };
    }).sort(function (a, b) { return b.count - a.count; }).slice(0, 5);
    api.json(res, 200, { success: true, period: period, list: list });
  });
};
