NXModules.register('monthly-fund', {
  mount: function (el, ctx) {
    el.innerHTML =
      '<div class="top"><div class="amt"><span class="raised">0</span> <small>/ <span class="goal">0</span></small></div>' +
      '<div><span class="pct">0%</span></div></div>' +
      '<div class="track"><div class="fill"></div></div>' +
      '<div class="meta"><span class="month"></span><span class="left"></span></div>';
    var $ = function (s) { return el.querySelector(s); };
    function fmt(n, sym) { return sym + Number(n).toLocaleString('en-IN'); }
    function draw(d) {
      var pct = d.goal > 0 ? (d.raised / d.goal) * 100 : 0;
      var h = ctx.root.querySelector('.nx-title');
      if (h) h.textContent = d.label;
      $('.raised').textContent = fmt(d.raised, d.symbol);
      $('.goal').textContent = fmt(d.goal, d.symbol);
      $('.pct').textContent = Math.floor(pct) + '%';
      $('.month').textContent = d.month;
      $('.left').innerHTML = pct >= 100 ? '<span class="done">🎉 Goal reached! Thank you!</span>' : fmt(d.goal - d.raised, d.symbol) + ' to go';
      requestAnimationFrame(function () { requestAnimationFrame(function () { $('.fill').style.width = Math.min(100, pct) + '%'; }); });
    }
    function load() { return ctx.api('/state').then(draw).catch(function () { $('.left').textContent = 'Could not load.'; }); }
    load();
    setInterval(load, 30000); // line moves live when someone buys
  }
});
