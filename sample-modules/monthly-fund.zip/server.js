// GET /api/m/monthly-fund/state (public). The goal/symbol/title are set ONLY by the admin in Admin > Modules > Edit.
module.exports = function (api) {
  function raisedThisMonth() {
    var now = new Date();
    var from = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    return api.db.sales().reduce(function (sum, s) {
      return String(s.createdAt) >= from ? sum + (Number(s.amount) || 0) : sum;
    }, 0);
  }
  api.get('/state', function (req, res) {
    var c = api.settings();
    res.setHeader('Cache-Control', 'no-cache');
    api.json(res, 200, {
      success: true,
      goal: c.goal, symbol: c.symbol, label: c.label,
      raised: raisedThisMonth(),
      month: new Date().toLocaleString('en', { month: 'long', year: 'numeric' })
    });
  });
};
